

export default  function Footer(){
    return<div className="footcon">
        <div className="givefeedback">
            <p>We'd love to here what you think!</p>
            <button>Give feedback</button>
        </div>

        <div className="footlist">
        <a>All Departments</a>
        <a>Store Directory</a>
        <a>Careers</a>
        <a>Our Company</a>
        <a>Sell on Walmart.com</a>
        <a>Help</a>
        <a>COVID-19 Vaccine Scheduler</a>
        <a>Product Recalls</a>
        <a>Accessibility</a>
        <a>Tax Exempt Program</a>
        <a>Get the Walmart App</a>
        <a>Sign-up for Email</a>
        <a>Safety Data Sheet</a>
        <a>Terms of Use</a>
        <a>Privacy & Security</a>
        <a>CA Privacy Rights</a>
        <a>California Supply Chain Act</a>
        <a>Privacy choices iconYour Privacy Choices</a>
        <a>Notice at Collection</a>
        <a>Request My Personal Information</a>
        <a>#IYWYK</a>
        </div>

        <p>© 2023 Walmart. All Rights Reserved.</p>
    </div>
}